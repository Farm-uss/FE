// src/apis/scheduleService.ts
// Swagger 스크린샷 기준 10개 엔드포인트 매핑

import type {
    ApiResponse,
    ConditionBasedScheduleDetail,
    ConditionBasedScheduleRequest,
    ScheduleHistoryItem,
    ScheduleListItem,
    TimeBasedScheduleDetail,
    TimeBasedScheduleRequest,
    ToggleEnabledRequest,
    ToggleEnabledResponse,
} from '@/types/schedule';

import axiosInstance from './axios';

/* ============== 1. 시간 기반 스케줄 등록 ============== */
/** POST /api/schedules/time-based */
export const createTimeBasedSchedule = async (
    body: TimeBasedScheduleRequest,
): Promise<TimeBasedScheduleDetail> => {
    const response = await axiosInstance.post<
        ApiResponse<TimeBasedScheduleDetail>
    >('/api/schedules/time-based', body);
    return response.data.data;
};

/* ============== 2. 조건 기반 스케줄 등록 ============== */
/** POST /api/schedules/condition-based */
export const createConditionBasedSchedule = async (
    body: ConditionBasedScheduleRequest,
): Promise<ConditionBasedScheduleDetail> => {
    const response = await axiosInstance.post<
        ApiResponse<ConditionBasedScheduleDetail>
    >('/api/schedules/condition-based', body);
    return response.data.data;
};

/* ============== 3. 시간 기반 스케줄 상세 조회 ============== */
/** GET /api/schedules/{scheduleId}/time-based */
export const getTimeBasedSchedule = async (
    scheduleId: number,
): Promise<TimeBasedScheduleDetail> => {
    const response = await axiosInstance.get<
        ApiResponse<TimeBasedScheduleDetail>
    >(`/api/schedules/${scheduleId}/time-based`);
    return response.data.data;
};

/* ============== 4. 시간 기반 스케줄 수정 ============== */
/** PUT /api/schedules/{scheduleId}/time-based */
export const updateTimeBasedSchedule = async (
    scheduleId: number,
    body: TimeBasedScheduleRequest,
): Promise<TimeBasedScheduleDetail> => {
    const response = await axiosInstance.put<
        ApiResponse<TimeBasedScheduleDetail>
    >(`/api/schedules/${scheduleId}/time-based`, body);
    return response.data.data;
};

/* ============== 5. 조건 기반 스케줄 상세 조회 ============== */
/** GET /api/schedules/{scheduleId}/condition-based */
export const getConditionBasedSchedule = async (
    scheduleId: number,
): Promise<ConditionBasedScheduleDetail> => {
    const response = await axiosInstance.get<
        ApiResponse<ConditionBasedScheduleDetail>
    >(`/api/schedules/${scheduleId}/condition-based`);
    return response.data.data;
};

/* ============== 6. 조건 기반 스케줄 수정 ============== */
/** PUT /api/schedules/{scheduleId}/condition-based */
export const updateConditionBasedSchedule = async (
    scheduleId: number,
    body: ConditionBasedScheduleRequest,
): Promise<ConditionBasedScheduleDetail> => {
    const response = await axiosInstance.put<
        ApiResponse<ConditionBasedScheduleDetail>
    >(`/api/schedules/${scheduleId}/condition-based`, body);
    return response.data.data;
};

/* ============== 7. 스케줄 활성화 여부 변경 ============== */
/** PATCH /api/schedules/{scheduleId}/enabled */
export const toggleScheduleEnabled = async (
    scheduleId: number,
    enabled: boolean,
): Promise<ToggleEnabledResponse> => {
    const body: ToggleEnabledRequest = { enabled };
    const response = await axiosInstance.patch<
        ApiResponse<ToggleEnabledResponse>
    >(`/api/schedules/${scheduleId}/enabled`, body);
    return response.data.data;
};

/* ============== 8. 농장별 스케줄 목록 조회 ============== */
/** GET /api/schedules?farmId={farmId} */
export const getSchedulesByFarm = async (
    farmId: number,
): Promise<ScheduleListItem[]> => {
    const response = await axiosInstance.get<ApiResponse<ScheduleListItem[]>>(
        '/api/schedules',
        { params: { farmId } },
    );
    return response.data.data;
};

/* ============== 9. 특정 스케줄 실행 이력 조회 ============== */
/** GET /api/schedules/{scheduleId}/histories */
export const getScheduleHistories = async (
    scheduleId: number,
): Promise<ScheduleHistoryItem[]> => {
    const response = await axiosInstance.get<ApiResponse<ScheduleHistoryItem[]>>(
        `/api/schedules/${scheduleId}/histories`,
    );
    return response.data.data;
};

/* ============== 10. 농장 전체 스케줄 실행 이력 조회 ============== */
/** GET /api/schedules/histories?farmId={farmId} */
export const getFarmScheduleHistories = async (
    farmId: number,
): Promise<ScheduleHistoryItem[]> => {
    const response = await axiosInstance.get<ApiResponse<ScheduleHistoryItem[]>>(
        '/api/schedules/histories',
        { params: { farmId } },
    );
    return response.data.data;
};

/* ============== (선택) 스케줄 삭제 ============== */
/**
 * ⚠️ 주의: 제공된 Swagger 스크린샷에는 DELETE 명세가 없음.
 * UI(스와이프 삭제)에서 필요해서 RESTful 컨벤션 기준으로 추정 작성.
 * 백엔드와 정확한 엔드포인트/메서드 확인 필요.
 *
 * 임시로 enabled=false 토글로 대체하고 싶다면 toggleScheduleEnabled 사용 권장.
 */
export const deleteSchedule = async (scheduleId: number): Promise<void> => {
    await axiosInstance.delete(`/api/schedules/${scheduleId}`);
};
