import { Icon } from '@iconify/react';
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import api from '@/apis/axios';
import Footer from '@/component/constants/Footer';
import LazyImage from '@/component/constants/LazyImage';
import BottomSheetHeader from '@/component/farm/farmDetail/BottomSheetHeader';

interface GrowthDiaryDetail {
  date: string;
  imageUrl: string;
  temperature: {
    min: number;
    max: number;
    avg: number;
  };
  growth: {
    leafCount: number;
    fruitCount: number;
    sizeCm: number;
  };
  gdd: {
    daily: number;
    cumulative: number;
  };
  disease: {
    name: string;
    confidence: number;
  };
}

const DUMMY_DATA: GrowthDiaryDetail = {
  date: '2025-12-14',
  imageUrl: '',
  temperature: {
    min: 24,
    max: 24,
    avg: 24,
  },
  growth: {
    leafCount: 2,
    fruitCount: 3,
    sizeCm: 2,
  },
  gdd: {
    daily: 1.8,
    cumulative: 12.5,
  },
  disease: {
    name: '잎 마름병',
    confidence: 88,
  },
};

const FarmStreamingPage = () => {
  const { farmId, cropsId } = useParams();

  const [currentDate, setCurrentDate] = useState<Date>(new Date());

  const [diaryData, setDiaryData] = useState<GrowthDiaryDetail | null>(
    DUMMY_DATA,
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handlePrevWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  const formatDateForAPI = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatDateForUI = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}.${month}.${day}`;
  };

  useEffect(() => {
    const fetchDiaryData = async () => {
      if (!farmId || !cropsId) {
        setDiaryData(DUMMY_DATA);
        return;
      }

      setIsLoading(true);
      const dateStr = formatDateForAPI(currentDate);

      try {
        const response = await api.get(
          `/api/v1/farms/${farmId}/crops/${cropsId}/growth-diary/${dateStr}`,
        );

        if (response.status === 200 && response.data) {
          setDiaryData(response.data);
        } else {
          setDiaryData(DUMMY_DATA);
        }
      } catch (error) {
        console.error(
          '성장 일기를 불러오는데 실패했습니다. 더미 데이터를 표시합니다.',
          error,
        );
        setDiaryData(DUMMY_DATA);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDiaryData();
  }, [currentDate, farmId, cropsId]);

  return (
    <div className="flex-1 flex flex-col items-center bg-[#E6E0D3]/50 rounded-t-[30px] py-6 px-6 w-full">
      <BottomSheetHeader
        title={'동열이네 성장일기'}
        description="하루하루, 내 농장을 체크하세요!"
      />

      <div className="w-full -mt-8">
        <div className="w-full flex justify-end text-[12px] font-medium text-[#2A160C] pb-1 border-b border-[#2A160C]/30">
          GDD
        </div>

        <div className="w-full flex items-center justify-between py-4">
          <button onClick={handlePrevWeek}>
            <Icon
              icon="ph:caret-left-fill"
              className="text-[20px] text-[#2A160C]"
            />
          </button>

          <span className="text-[18px] font-bold text-[#2A160C]">
            {currentDate.getMonth() + 1}월
          </span>

          <button onClick={handleNextWeek}>
            <Icon
              icon="ph:caret-right-fill"
              className="text-[20px] text-[#2A160C]"
            />
          </button>
        </div>

        <div className="w-full bg-white rounded-[24px] mt-2 px-5 py-6 flex flex-col items-center min-h-[400px]">
          <div className="text-[18px] font-bold text-[#2A160C] mb-5">
            {formatDateForUI(currentDate)}
          </div>

          {isLoading ? (
            <div className="w-full h-[300px] flex items-center justify-center text-[#8B8880] font-medium">
              데이터를 불러오는 중입니다...
            </div>
          ) : diaryData ? (
            <>
              <div className="w-full h-[220px] bg-[#D9D3C3] rounded-[20px] overflow-hidden flex items-center justify-center">
                {diaryData.imageUrl ? (
                  <LazyImage
                    src={diaryData.imageUrl}
                    alt="diary"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Icon
                    icon="mdi:image-outline"
                    className="text-[90px] text-[#8B8880]"
                  />
                )}
              </div>

              <div className="w-full grid grid-cols-2 gap-3 mt-4">
                <div className="flex flex-col gap-3">
                  <div className="bg-[#E6E0D3] rounded-[20px] p-4 flex-1 flex flex-col justify-center items-center text-center text-[#2A160C]">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="font-bold text-[16px]">온도</span>
                      <span className="text-[15px]">
                        평균 : {diaryData.temperature.avg}도
                      </span>
                    </div>
                    <div className="text-[14px] text-[#2A160C]/70 mt-1">
                      최저 {diaryData.temperature.min}도 / 최고{' '}
                      {diaryData.temperature.max}도
                    </div>
                  </div>

                  <div className="bg-[#E6E0D3] rounded-[20px] p-4 flex-1 flex flex-col justify-center items-center text-center text-[#2A160C]">
                    <div className="font-bold text-[16px] leading-tight mb-2">
                      "{diaryData.disease.name}" 에 취약합니다.
                    </div>
                    <div className="text-[14px] text-[#2A160C]/70">
                      신뢰도 {diaryData.disease.confidence}%
                    </div>
                  </div>
                </div>

                <div className="bg-[#E6E0D3] rounded-[20px] px-5 py-5 text-[#2A160C] flex flex-col justify-center">
                  <div className="font-bold mb-3 text-[16px]">성장</div>
                  <div className="flex flex-col gap-2.5 text-[15px] text-[#2A160C]/90">
                    <div>작물 높이 : +{diaryData.growth.sizeCm}cm</div>
                    <div>잎 갯수 +{diaryData.growth.leafCount}개</div>
                    <div>열매 갯수 +{diaryData.growth.fruitCount}</div>
                    <div>GDD : +{diaryData.gdd.daily}</div>
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </div>

        <div className="w-full text-center mt-10 mb-4 text-[#8B8880] text-[14px] font-medium">
          Smart FARM, Smart US.
        </div>

        <div>
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default FarmStreamingPage;
