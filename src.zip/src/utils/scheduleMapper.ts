import type {
    ConditionOperator,
    ControlSystemType,
    DayOfWeek,
    SensorType,
} from '@/types/schedule';


const SYSTEM_UI_TO_API: Record<string, ControlSystemType> = {
    irrigation: 'IRRIGATION',
    lighting: 'LIGHTING',
    ventilation: 'VENTILATION',
    heating: 'HEATING',
    camera: 'CAMERA',
};

const SYSTEM_API_TO_UI: Record<ControlSystemType, string> = {
    IRRIGATION: 'irrigation',
    LIGHTING: 'lighting',
    VENTILATION: 'ventilation',
    HEATING: 'heating',
    CAMERA: 'camera',
};

export const toApiControlSystem = (ui: string): ControlSystemType =>
    SYSTEM_UI_TO_API[ui] ?? 'IRRIGATION';

export const toUiControlSystem = (api: ControlSystemType): string =>
    SYSTEM_API_TO_UI[api] ?? 'irrigation';

const SENSOR_UI_TO_API: Record<string, SensorType> = {
    temperature: 'TEMPERATURE',
    soilMoisture: 'SOIL_MOISTURE',
    humidity: 'HUMIDITY',
    illuminance: 'ILLUMINANCE',
    co2: 'CO2',
};

const SENSOR_API_TO_UI: Record<SensorType, string> = {
    TEMPERATURE: 'temperature',
    SOIL_MOISTURE: 'soilMoisture',
    HUMIDITY: 'humidity',
    ILLUMINANCE: 'illuminance',
    CO2: 'co2',
};

export const toApiSensor = (ui: string): SensorType =>
    SENSOR_UI_TO_API[ui] ?? 'TEMPERATURE';

export const toUiSensor = (api: SensorType): string =>
    SENSOR_API_TO_UI[api] ?? 'temperature';

const OP_UI_TO_API: Record<string, ConditionOperator> = {
    greater: 'GREATER_THAN',
    less: 'LESS_THAN',
    equal: 'EQUAL',
};

const OP_API_TO_UI: Record<ConditionOperator, string> = {
    GREATER_THAN: 'greater',
    LESS_THAN: 'less',
    EQUAL: 'equal',
};

export const toApiOperator = (ui: string): ConditionOperator =>
    OP_UI_TO_API[ui] ?? 'GREATER_THAN';

export const toUiOperator = (api: ConditionOperator): string =>
    OP_API_TO_UI[api] ?? 'greater';

const DAY_UI_TO_API: Record<string, DayOfWeek> = {
    월: 'MONDAY',
    화: 'TUESDAY',
    수: 'WEDNESDAY',
    목: 'THURSDAY',
    금: 'FRIDAY',
    토: 'SATURDAY',
    일: 'SUNDAY',
};

const DAY_API_TO_UI: Record<DayOfWeek, string> = {
    MONDAY: '월',
    TUESDAY: '화',
    WEDNESDAY: '수',
    THURSDAY: '목',
    FRIDAY: '금',
    SATURDAY: '토',
    SUNDAY: '일',
};

export const toApiDays = (uiDays: string[]): DayOfWeek[] =>
    uiDays.map((d) => DAY_UI_TO_API[d]).filter(Boolean) as DayOfWeek[];

export const toUiDays = (apiDays: DayOfWeek[]): string[] =>
    apiDays.map((d) => DAY_API_TO_UI[d]).filter(Boolean);

export const toLocalTime = (hourStr: string, minuteStr: string) => ({
    hour: Number(hourStr) || 0,
    minute: Number(minuteStr) || 0,
    second: 0,
    nano: 0,
});

export const formatExecutedAt = (iso: string | null | undefined): string => {
    if (!iso) return '-';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '-';
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    return `${yyyy}.${mm}.${dd} ${hh}:${mi}`;
};
